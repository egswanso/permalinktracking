/*
 * This code goes on the page containing the perma link
 */
document.body.onclick = function (e) {

	e = e || event;
	var goTo = checkLinkClick('a', e.target || e.srcElement);

	if (goTo) {

		// see if link matches a permalink
		if (checkIfPermaLink(goTo.href) && checkIfLocalStorageVarsSet()) {

			// Stop the link
			e.preventDefault();

			// Go to redirect page
			goToRedirectPage(goTo.href);

		}

	}

};

function checkLinkClick(checker, el)
{

	while (el) {

		if ((el.nodeName || el.checker).toLowerCase() === checker.toLowerCase()) {
			return el;
		}
		el = el.parentNode;

	}

	return null;

}

function checkIfPermaLink(url)
{

	if (getPermaLinkValue(url).indexOf(':') > -1) {
		return true;
	} else {
		return false;
	}

}

function getPermaLinkValue(url)
{

	var splitUrl = url.split('/');

	// check if there is a query string on the end of this
	if (splitUrl[splitUrl.length - 1].indexOf('?') > -1) {

		var secondSplit = splitUrl[splitUrl.length - 1].split('?');
		return secondSplit[0];

	} else {
		return splitUrl[splitUrl.length - 1];
	}

}

function checkIfLocalStorageVarsSet()
{

	if (
		localStorage.getItem('rfsn_aid') === null
		|| localStorage.getItem('rfsn_ci') === null
		|| localStorage.getItem('rfsn_cs') === null
	) {
		return false;
	} else {
		return true;
	}
}

function goToRedirectPage(originalUrl)
{

	/**
	 * Change the value of the variable below to be your custom redirect page
	 */

	var redirectPageSlug = 'custom-cart';

	/******************************
	 * DO NOT CHANGE ANYTHING ELSE *
	 ******************************/

	var permaValue = getPermaLinkValue(originalUrl);
	redirectPageSlug = '/pages/' + redirectPageSlug + '/';
	var new_href_sep = '?';

	if (originalUrl.indexOf('?') > -1) {
		new_href_sep = '&';
	}

	window.location.href = originalUrl.replace(permaValue, '').replace('/cart/', redirectPageSlug)
						   + new_href_sep + 'rfsnperma_aid='
						   + localStorage.getItem('rfsn_aid')
						   + '&rfsnperma_ci='
						   + localStorage.getItem('rfsn_ci')
						   + '&rfsnperma_cs='
						   + localStorage.getItem('rfsn_cs')
						   + '&rfsnperma_click='
						   + localStorage.getItem('current_rfsn_click')
						   + '&rfsnperma_crlsts='
						   + localStorage.getItem('current_rfsn_lsts')
						   + '&permavalue=' + encodeURIComponent(permaValue);
}

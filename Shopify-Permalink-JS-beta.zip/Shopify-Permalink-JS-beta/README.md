# Shopify-Permalink-JS
A work around to make Shopify permalinks work with Refersion link tracking. 


## Instructions
1. Create a new custom page on the Shopify store that will be used to handle redirects.
2. Replace the value of `redirectPageSlug` in the code `redirect-on-custom-page.js` with the slug of the newly created page.
3. Add the modified code from `redirect-on-custom-page.js` to newly created page.
2. Replace the value of `redirectPageSlug` in the code `intercept-links.js` with the slug of the newly created page.
5. Add the modified code from `intercept-links.js` to every page that contains a permalink.
6. Add the code from `post-purchase-cart.js` to the Shopify checkout.

##### Notes
The modified code should be minified too before using.
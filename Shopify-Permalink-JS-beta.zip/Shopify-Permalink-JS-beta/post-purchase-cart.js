/*
 * This code goes on post purchase page
 */
function rfsnRunOnLoad()
{
	_refersion(function () {
		if (
			localStorage.getItem('rfsnperma_future_ct') === null
			|| localStorage.getItem('rfsnperma_future_ct') === 'null'
		) {

		} else {
			_rfsn._addCart(localStorage.getItem('rfsnperma_future_ct'));
		}

	})
}

if (window.addEventListener) {
	window.addEventListener("load", rfsnRunOnLoad, !1);
} else if (window.attachEvent) {
	window.attachEvent("onload", rfsnRunOnLoad);
} else {
	window.onload = rfsnRunOnLoad;
}

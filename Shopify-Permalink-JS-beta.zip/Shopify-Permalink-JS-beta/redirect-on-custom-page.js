/*
 * This code goes on the fake redirect page on the shopify store
 */
(function () {
	var qs = getQueryString(window.location.href);


	var pqs = parseQueryString(qs);

	if (checkIfUrlVarsSet(pqs)) {
		addStorageValues(pqs);
		rebuildCorrectLink(qs, pqs)
	}

})();

function getQueryString(url)
{
	var splitUrl = url.split('?')
	return splitUrl[splitUrl.length - 1];
}

function parseQueryString(query)
{
	var vars = query.split("&");
	var query_string = {};
	for (var i = 0; i < vars.length; i++) {
		var pair = vars[i].split("=");
		var key = decodeURIComponent(pair[0]);
		var value = decodeURIComponent(pair[1]);
		if (typeof query_string[key] === "undefined") {
			query_string[key] = decodeURIComponent(value);
		} else if (typeof query_string[key] === "string") {
			var arr = [query_string[key], decodeURIComponent(value)];
			query_string[key] = arr;
		} else {
			query_string[key].push(decodeURIComponent(value));
		}
	}
	return query_string;
}

function checkIfUrlVarsSet(pqs)
{
	if (
		pqs.permavalue === null
		|| pqs.rfsnperma_aid === null
		|| pqs.rfsnperma_ci === null
		|| pqs.rfsnperma_cs === null
	) {
		return false;
	} else {
		return true;
	}
}

function addStorageValues(pqs)
{
	localStorage.setItem('rfsn_aid', pqs.rfsnperma_aid);
	localStorage.setItem('rfsn_ci', pqs.rfsnperma_ci);
	localStorage.setItem('rfsn_cs', pqs.rfsnperma_cs);
	if (pqs.rfsnperma_click && pqs.rfsnperma_click !== 'null') {
		localStorage.setItem('current_rfsn_click', pqs.rfsnperma_click);
	}
	if (pqs.rfsnperma_crlsts && pqs.rfsnperma_crlsts !== 'null') {
		localStorage.setItem('current_rfsn_lsts', pqs.rfsnperma_crlsts);
	}
}

function addCartOverrideAttribute(url, cartToken)
{
	var new_href_sep = '?';

	if (url.indexOf('?') > -1) {
		new_href_sep = '&';
	}

	return url + new_href_sep + 'attributes[rfsnCartOverrideToken]=' + cartToken;
}

function rebuildCorrectLink(qs, pqs)
{

	/**
	 * Change the value of the variable below to be your custom redirect page
	 */

	var redirectPageSlug = 'custom-cart';

	/******************************
	 * DO NOT CHANGE ANYTHING ELSE *
	 ******************************/

	redirectPageSlug = '/pages/' + redirectPageSlug + '/';

	var newLink = window.location.href.replace(redirectPageSlug, '/cart/').replace(qs, '').replace('?', '').replace('&', '') + pqs.permavalue;

	// Build new random cart token (long) to override with
	var cartToken = Math.random().toString(28).replace('0.', '') + Math.random().toString(28).replace('0.', '') + Math.random().toString(28).replace('0.', '') + Math.random().toString(28).replace('0.', '');

	localStorage.setItem('rfsnperma_future_ct', cartToken);

	window.location.href = addCartOverrideAttribute(newLink, cartToken);

}
